//
//  FalconSDK.h
//  FalconSDK
//
//

#import <Foundation/Foundation.h>

//! Project version number for FalconSDK.
FOUNDATION_EXPORT double FalconSDKVersionNumber;

//! Project version string for FalconSDK.
FOUNDATION_EXPORT const unsigned char FalconSDKVersionString[];


